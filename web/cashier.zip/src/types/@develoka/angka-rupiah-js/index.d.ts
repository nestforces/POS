declare module "@develoka/angka-rupiah-js";
