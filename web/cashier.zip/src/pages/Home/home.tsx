import { Box } from "@chakra-ui/react"

export const Home = () => {
  return (
    <Box>
      Home
    </Box>
  )
}