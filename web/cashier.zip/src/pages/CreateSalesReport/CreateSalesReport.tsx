import { Box } from "@chakra-ui/react"

export const CreateSalesReport = () => {
  return (
    <Box>
      Home
    </Box>
  )
}