import { Box } from "@chakra-ui/react"

export const GraphSale = () => {
  return (
    <Box>
      Graph Sale
      
    </Box>
  )
}