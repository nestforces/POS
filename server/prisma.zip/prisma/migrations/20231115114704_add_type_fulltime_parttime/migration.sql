-- AlterTable
ALTER TABLE `users` ADD COLUMN `type` VARCHAR(255) NULL;
