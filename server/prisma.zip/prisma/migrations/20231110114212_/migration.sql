/*
  Warnings:

  - You are about to drop the `_categoriesToproducts` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE `_categoriesToproducts` DROP FOREIGN KEY `_categoriesToproducts_A_fkey`;

-- DropForeignKey
ALTER TABLE `_categoriesToproducts` DROP FOREIGN KEY `_categoriesToproducts_B_fkey`;

-- DropTable
DROP TABLE `_categoriesToproducts`;
