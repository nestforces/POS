-- AlterTable
ALTER TABLE `users` ADD COLUMN `test` VARCHAR(255) NULL;
